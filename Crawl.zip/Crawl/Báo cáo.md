
## 1. HTML for Web Scraping
### 1.1 HTML element syntax:
![[Pasted image 20250731234940.png]]
### 1.2 Ví dụ
Một thẻ HTML như `<article>` là **một phần tử duy nhất**, nhưng trong thực tế, **một trang web có hàng trăm hoặc hàng nghìn phần tử HTML** như vậy được **lồng ghép với nhau thành một cấu trúc cây**.

```
<article class="main-article">
  <h1> Titanic (1997) </h1>
  <p class="plot"> 84 years later ... </p>
  <div class="full-script"> 13 meters. You ... </div>
</article>
```
Đoạn HTML trên được trình duyệt phân tích thành cây DOM như sau:
HTML code được cấu trúc bởi các "nodes" - **element, attribute và text nodes.**
![[Pasted image 20250731235016.png]]
> *Note*: cần **hiểu cấu trúc DOM** để viết chính xác `CSS selector`, `XPath`, hoặc dùng `BeautifulSoup`, `Selenium` để **lấy đúng dữ liệu**

## 2. Beautiful Soup
### Workflow
#### Import the libraries
```
from bs4 import BeautifulSoup 
import requests
```

#### Fetch the pages
```
result=requests.get("www.google.com")

# get status code 
result.status_code 

# get the headers
result.headers 
```

#### Page Content
```
content = result.text
```

#### Create soup
```
soup = BeautifulSoup(content,"lxml")
###
soup = BeautifulSoup(content,"html.parser")
```
#### HTML in a readable format 
```
print(soup.prettify()) 
```
#### Find an element 
```
soup.find(id="specific_id")
``` 

#### Find elements
```
soup.find_all("a") 
soup.find_all("a","css_class") soup.find_all("a",class_="my_class") 
soup.find_all("a",attrs={"class": "my_class"})
```

#### Get inner text 
```
sample = element.get_text() sample = element.get_text(strip=True, separator= ' ')
```
#### Get specific attributes 
```
sample = element.get('href')
```

## 3. XPath
Cần sử dụng **XPath** để scrape với `Selenium` hoặc `Scrapy`
### 3.1 XPath Syntax
```
//tagName[@AttributeName="Value"]
```
VD: 
```
//article[@class="main-article"] 
//h1 
//div[@class="full-script"]
```

### 3.2 XPath Functions and Operators
- XPath functions
```
//tag[contains(@AttributeName, "Value")]
```
- XPath Operators: and, or
```
//tag[(expression 1) and (expression 2)]
```

## 4. Selenium
Là một công cụ tự động hóa trình duyệt web. Được thiết kế để web scraping nâng cao, với những trang web dùng JavaScript.

> NOTE:
> - Trang web dùng JavaScript để load dữ liệu
> - Cần thực hiện thao tác như người dùng

#### Import libraries:
```
from selenium import webdriver from selenium.webdriver.chrome.service import Service

web="www.google.com" 
path='introduce chromedriver path' 
service = Service(executable_path=path) # selenium 4 
driver = webdriver.Chrome(service=service) # selenium 4 driver.get(web) 

Note: driver = webdriver.Chrome(path) # selenium 3.x
```
#### Find an element
```
driver.find_element(by="id", value="...") # selenium 4 driver.find_element_by_id("write-id-here") # selenium 3.x
```
#### Find elements
```
driver.find_elements(by="xpath", value="...") # selenium 4 driver.find_elements_by_xpath("write-xpath-here") # selenium 3.x
```
#### Quit driver
```
driver.quit()
```
#### Getting the text()
```
data = element.text
```
#### Implicit Waits
```
import time 
time.sleep(2)
```
#### Explicit Waits
```
from selenium.webdriver.common.by import By 
from selenium.webdriver.support.ui import WebDriverWait 
from selenium.webdriver.support import expected_conditions as EC

WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.ID, 'id_name'))) 
### Wait 5 seconds until an element is clickable
```
#### Options: Headless mode, change window size
```
from selenium.webdriver.chrome.options import Options 
options = Options() 
options.headless = True 
options.add_argument('window-size=1920x1080') driver=webdriver.Chrome(service=service,options=options)
```

## 5. Scrapy
Scrapy là framework thu thập dữ liệu web mạnh mẽ nhất trong Python.
#### Creating a Project and Spider
```
scrapy startproject my_first_spider
cd my_first_spider

###Create an spider 
scrapy genspider example example.com
```

#### The basic template 
Khi chạy lệnh `scrapy genspider`, Scrapy sẽ tự tạo ra một file spider với class chứa tên spider, domain được phép crawl, và hàm `start_requests` hoặc `parse`.
![[Pasted image 20250801002305.png]]

#### Finding elements
```
response.xpath('//tag[@AttributeName="Value"]')
```

#### Getting the text
``` 
response.xpath('//h1/text()').get() response.xpath('//tag[@Attribute="Value"]/text()'.getall()
```
#### Return data extracted
Để xem dữ liệu đã được trích xuất, sử dụng từ khóa `yield`.

```
def parse(self, response): 
title = response.xpath('//h1/text()').get() 

# Return data extracted 
yield {'titles': title}
```

#### Run the spider and export data to CSV or JSON
```
scrapy crawl example 
scrapy crawl example -o name_of_file.csv 
scrapy crawl example -o name_of_file.json
```


## So sánh chung

| **Tiêu chí**                      | **`requests` + BeautifulSoup**                   | **`Selenium`**                                    | **`Scrapy`**                                            |
| --------------------------------- | ------------------------------------------------ | ------------------------------------------------- | ------------------------------------------------------- |
| **Loại trang phù hợp**            | Web tĩnh (HTML hiển thị sẵn)                     | Web động (dùng JavaScript)                        | Web tĩnh hoặc có thể xử lý link động qua callback       |
| **Xử lý JavaScript**              | Không hỗ trợ                                     | Có – trình duyệt thực thi JS                      | Không thực thi JS (trừ khi tích hợp Splash, Playwright) |
| **Tốc độ**                        | Rất nhanh (vì nhẹ và đơn giản)                   | Chậm hơn (vì chạy cả trình duyệt)                 | Rất nhanh, tối ưu crawl số lượng lớn                    |
| **Tài nguyên sử dụng (CPU/RAM)**  | Thấp                                             | Cao (chạy trình duyệt như Chrome)                 | Thấp – hỗ trợ async, đa luồng hiệu quả                  |
| **Khả năng tương tác**            | Không tương tác được (bấm nút, scroll, v.v.)     | Có thể tương tác như người dùng                   | Không có (trừ khi kết hợp với Splash)                   |
| **Tự động hóa crawl nhiều trang** | Phải tự xử lý thủ công                           | Phải tự viết vòng lặp, tương tác                  | Hỗ trợ built-in (pagination, crawl rule, callback)      |
| **Tích hợp xuất CSV/JSON**        | Phải tự viết code                                | Phải tự xử lý                                     | Có sẵn                                                  |
| **Use-case phù hợp**              | Scrape bảng dữ liệu, text từ trang HTML đơn giản | Scrape trang có JS, form đăng nhập, scroll vô hạn | Crawl toàn site, nhiều trang, nhiều domain, tốc độ cao  |
### So sánh 3 công cụ khi xử lý nhiều request:

| **Tiêu chí**                              | **`requests` + BeautifulSoup`**                          | **`Selenium`**                                                | **`Scrapy`**                                                     |
| ----------------------------------------- | -------------------------------------------------------- | ------------------------------------------------------------- | ---------------------------------------------------------------- |
| **Tốc độ gửi nhiều request**              | Chậm, cần dùng thêm `threading` để tăng tốc              | Rất chậm, không phù hợp (vì chạy trình duyệt cho mỗi request) | Rất nhanh – sử dụng bất đồng bộ (async + event-driven)           |
| **Hiệu suất khi crawl hàng ngàn URL**     | Hạn chế – cần tối ưu nhiều (session pool, retry)         | Không khuyến nghị – tốn RAM/CPU, dễ crash                     | Rất phù hợp – có queue, pool, retry, auto-throttle               |
| **Khả năng kiểm soát tốc độ gửi request** | Có, nhưng phải viết thủ công (`time.sleep`, `Semaphore`) | Có thể dùng `time.sleep` hoặc `wait`                          | Tích hợp sẵn `DOWNLOAD_DELAY`, `AUTOTHROTTLE`                    |
| **Xử lý lỗi khi bị block (403, 429)**     | Phải tự bắt lỗi, retry lại                               | Có thể thêm retry, nhưng không hiệu quả                       | Có sẵn middleware retry, ban detection                           |
| **Hỗ trợ proxy, rotate UA**               | Có, nhưng phải tự làm                                    | Dễ thực hiện                                                  | Tích hợp tốt (middleware proxy, rotate user-agent, fake headers) |
| **Khả năng lưu log, debug nhiều request** | Khó theo dõi nếu request nhiều                           |                                                               | Có hệ thống log chi tiết, phân tích theo domain/response         |
| **Khả năng mở rộng quy mô (scalable)**    | Không phù hợp                                            | Không phù hợp                                                 | Có thể triển khai phân tán (với scrapyd, Frontera, Redis queue)  |