import requests
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from queue import Queue
import random
from urllib.parse import urljoin
import json
from datetime import datetime

class MultiRequestScraper:
    def __init__(self, base_url, max_workers=10, delay=0.1):
        """
        Khởi tạo scraper với threading
        
        Args:
            base_url (str): URL cơ sở để gửi requests
            max_workers (int): Số lượng threads tối đa
            delay (float): Thời gian delay giữa các requests (giây)
        """
        self.base_url = base_url
        self.max_workers = max_workers
        self.delay = delay
        self.session = requests.Session()
        self.results = []
        self.errors = []
        self.lock = threading.Lock()
        
        # Headers để giả lập browser
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        })
    
    def make_request(self, url, params=None, timeout=10):
        """
        Thực hiện một request đơn lẻ
        
        Args:
            url (str): URL để gửi request
            params (dict): Parameters cho request
            timeout (int): Timeout cho request
            
        Returns:
            dict: Kết quả request
        """
        try:
            # Thêm delay để tránh spam
            time.sleep(self.delay)
            
            response = self.session.get(url, params=params, timeout=timeout)
            response.raise_for_status()
            
            return {
                'url': url,
                'status_code': response.status_code,
                'content_length': len(response.content),
                'response_time': response.elapsed.total_seconds(),
                'success': True,
                'data': response.text[:500]  # Lưu 500 ký tự đầu tiên
            }
            
        except requests.exceptions.RequestException as e:
            return {
                'url': url,
                'error': str(e),
                'success': False
            }
    
    def worker(self, task_queue, result_queue):
        """
        Worker function cho threading
        
        Args:
            task_queue: Queue chứa các tasks
            result_queue: Queue để lưu kết quả
        """
        while True:
            try:
                task = task_queue.get_nowait()
                if task is None:
                    break
                
                url, params = task
                result = self.make_request(url, params)
                
                with self.lock:
                    if result['success']:
                        self.results.append(result)
                    else:
                        self.errors.append(result)
                
                result_queue.put(result)
                task_queue.task_done()
                
            except Exception as e:
                print(f"Worker error: {e}")
                task_queue.task_done()
    
    def scrape_with_threading(self, urls, params_list=None):
        """
        Scrape nhiều URLs sử dụng threading
        
        Args:
            urls (list): Danh sách URLs
            params_list (list): Danh sách parameters cho từng URL
        """
        if params_list is None:
            params_list = [{}] * len(urls)
        
        task_queue = Queue()
        result_queue = Queue()
        
        # Thêm tasks vào queue
        for i, url in enumerate(urls):
            params = params_list[i] if i < len(params_list) else {}
            task_queue.put((url, params))
        
        # Tạo và start workers
        threads = []
        for _ in range(self.max_workers):
            thread = threading.Thread(
                target=self.worker, 
                args=(task_queue, result_queue)
            )
            thread.start()
            threads.append(thread)
        
        # Chờ tất cả tasks hoàn thành
        task_queue.join()
        
        # Stop workers
        for _ in range(self.max_workers):
            task_queue.put(None)
        
        for thread in threads:
            thread.join()
        
        return self.results, self.errors
    
    def scrape_with_threadpool(self, urls, params_list=None):
        """
        Scrape sử dụng ThreadPoolExecutor (cách hiện đại hơn)
        
        Args:
            urls (list): Danh sách URLs
            params_list (list): Danh sách parameters cho từng URL
        """
        if params_list is None:
            params_list = [{}] * len(urls)
        
        results = []
        errors = []
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Tạo futures
            future_to_url = {}
            for i, url in enumerate(urls):
                params = params_list[i] if i < len(params_list) else {}
                future = executor.submit(self.make_request, url, params)
                future_to_url[future] = url
            
            # Xử lý kết quả
            for future in as_completed(future_to_url):
                try:
                    result = future.result()
                    if result['success']:
                        results.append(result)
                    else:
                        errors.append(result)
                except Exception as e:
                    errors.append({
                        'url': future_to_url[future],
                        'error': str(e),
                        'success': False
                    })
        
        return results, errors

def example_usage():
    """
    Ví dụ sử dụng MultiRequestScraper
    """
    # URL mẫu (thay thế bằng URL thực tế)
    base_url = "https://httpbin.org"
    
    # Tạo scraper
    scraper = MultiRequestScraper(
        base_url=base_url,
        max_workers=20,  # 20 threads
        delay=0.05  # 50ms delay giữa requests
    )
    
    # Tạo danh sách 1000 URLs
    urls = []
    for i in range(100):
        # Sử dụng httpbin để test
        url = f"{base_url}/get?request_id={i}"
        urls.append(url)
    
    print(f"Bắt đầu gửi {len(urls)} requests...")
    start_time = time.time()
    
    # Sử dụng ThreadPoolExecutor (khuyến nghị)
    results, errors = scraper.scrape_with_threadpool(urls)
    
    end_time = time.time()
    total_time = end_time - start_time
    
    # In kết quả
    print(f"\n=== KẾT QUẢ ===")
    print(f"Tổng thời gian: {total_time:.2f} giây")
    print(f"Requests thành công: {len(results)}")
    print(f"Requests thất bại: {len(errors)}")
    print(f"Tốc độ: {len(urls)/total_time:.2f} requests/giây")
    
    # Thống kê response times
    if results:
        response_times = [r['response_time'] for r in results if 'response_time' in r]
        if response_times:
            avg_response_time = sum(response_times) / len(response_times)
            print(f"Thời gian response trung bình: {avg_response_time:.3f} giây")
    
    # Lưu kết quả vào file
    save_results(results, errors, total_time)

def save_results(results, errors, total_time):
    """
    Lưu kết quả vào file JSON
    """
    output = {
        'timestamp': datetime.now().isoformat(),
        'summary': {
            'total_requests': len(results) + len(errors),
            'successful_requests': len(results),
            'failed_requests': len(errors),
            'total_time': total_time,
            'requests_per_second': (len(results) + len(errors)) / total_time
        },
        'results': results[:10],  # Chỉ lưu 10 kết quả đầu tiên
        'errors': errors[:10]     # Chỉ lưu 10 lỗi đầu tiên
    }
    
    with open('multi_requests_results.json', 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print(f"\nKết quả đã được lưu vào: multi_requests_results.json")

def advanced_example():
    """
    Ví dụ nâng cao với rate limiting và retry logic
    """
    import time
    from functools import wraps
    
    def retry_on_failure(max_retries=3, delay=1):
        """Decorator để retry khi request thất bại"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                for attempt in range(max_retries):
                    try:
                        return func(*args, **kwargs)
                    except Exception as e:
                        if attempt == max_retries - 1:
                            raise e
                        time.sleep(delay * (attempt + 1))
                return None
            return wrapper
        return decorator
    
    class AdvancedMultiRequestScraper(MultiRequestScraper):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.request_count = 0
            self.start_time = time.time()
        
        @retry_on_failure(max_retries=3, delay=1)
        def make_request(self, url, params=None, timeout=10):
            """Override với retry logic"""
            with self.lock:
                self.request_count += 1
                if self.request_count % 100 == 0:
                    elapsed = time.time() - self.start_time
                    print(f"Đã gửi {self.request_count} requests trong {elapsed:.2f}s")
            
            return super().make_request(url, params, timeout)
    
    # Sử dụng advanced scraper
    scraper = AdvancedMultiRequestScraper(
        base_url="https://httpbin.org",
        max_workers=15,
        delay=0.1
    )
    
    # Tạo URLs với parameters khác nhau
    urls = []
    params_list = []
    
    for i in range(100):
        urls.append(f"https://httpbin.org/get")
        params_list.append({
            'request_id': i,
            'timestamp': int(time.time()),
            'user_id': random.randint(1, 100)
        })
    
    print("Bắt đầu advanced scraping...")
    results, errors = scraper.scrape_with_threadpool(urls, params_list)
    
    print(f"Advanced scraping hoàn thành: {len(results)} thành công, {len(errors)} thất bại")

if __name__ == "__main__":
    print("=== VÍ DỤ MULTI-REQUEST SCRAPING ===")
    print("1. Basic example")
    print("2. Advanced example")
    
    choice = input("Chọn ví dụ (1 hoặc 2): ").strip()
    
    if choice == "2":
        advanced_example()
    else:
        example_usage()
