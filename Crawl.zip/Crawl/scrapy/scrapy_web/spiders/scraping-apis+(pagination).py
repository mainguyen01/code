import scrapy
import json
import time
from scrapy.exceptions import IgnoreRequest
from scrapy.http import Request
from scrapy.utils.response import response_status_message
import logging

class QuotesSpider(scrapy.Spider):
    name = 'quotes_advanced'
    allowed_domains = ['httpbin.org']
    start_urls = ['https://httpbin.org/get?page=1']
    
    # Cấu hình spider
    custom_settings = {
        'DOWNLOAD_DELAY': 1,  # Delay 1 giây giữa các requests
        'RANDOMIZE_DOWNLOAD_DELAY': True,  # Randomize delay
        'CONCURRENT_REQUESTS': 5,  # Số requests đồng thời
        'CONCURRENT_REQUESTS_PER_DOMAIN': 3,  # Requests per domain
        'AUTOTHROTTLE_ENABLED': True,  # Bật auto-throttle
        'AUTOTHROTTLE_START_DELAY': 1,  # Delay ban đầu
        'AUTOTHROTTLE_MAX_DELAY': 60,  # Delay tối đa
        'AUTOTHROTTLE_TARGET_CONCURRENCY': 2.0,  # Target concurrency
        'AUTOTHROTTLE_DEBUG': True,  # Debug auto-throttle
        'RETRY_ENABLED': True,  # Bật retry
        'RETRY_TIMES': 3,  # Số lần retry
        'RETRY_HTTP_CODES': [500, 502, 503, 504, 408, 429],  # HTTP codes để retry
        'DOWNLOAD_TIMEOUT': 30,  # Timeout cho download
        'COOKIES_ENABLED': False,  # Tắt cookies để tăng tốc
        'LOG_LEVEL': 'INFO',  # Log level
    }
    
    def __init__(self, max_pages=100, *args, **kwargs):
        super(QuotesSpider, self).__init__(*args, **kwargs)
        self.max_pages = int(max_pages)
        self.current_page = 1
        self.successful_pages = 0
        self.failed_pages = 0
        self.start_time = time.time()
        
        # Logging - sử dụng self.logger có sẵn của Scrapy
        self.logger.info(f"Spider khởi tạo với max_pages={self.max_pages}")
    
    def start_requests(self):
        """
        Override start_requests để thêm headers và meta data
        """
        for url in self.start_urls:
            yield Request(
                url=url,
                callback=self.parse,
                meta={
                    'page_number': 1,
                    'retry_count': 0,
                    'dont_cache': True
                },
                headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Accept': 'application/json, text/plain, */*',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Connection': 'keep-alive',
                    'Cache-Control': 'no-cache',
                },
                errback=self.errback_httpbin,
                dont_filter=True
            )
    
    def parse(self, response):
        """
        Parse response và xử lý pagination
        """
        page_number = response.meta.get('page_number', 1)
        
        # Log progress
        elapsed_time = time.time() - self.start_time
        self.logger.info(f"Đang xử lý trang {page_number}/{self.max_pages} - Thời gian: {elapsed_time:.2f}s")
        
        try:
            # Parse JSON response từ httpbin
            json_response = json.loads(response.body)
            
            # Extract data từ httpbin response
            args = json_response.get('args', {})
            headers = json_response.get('headers', {})
            url = json_response.get('url', '')
            origin = json_response.get('origin', '')
            
            # Yield data
            yield {
                'page_number': page_number,
                'url': url,
                'args': args,
                'origin': origin,
                'user_agent': headers.get('User-Agent', ''),
                'host': headers.get('Host', ''),
                'timestamp': time.time(),
                'response_size': len(response.body),
            }
            
            self.successful_pages += 1
            
            # Continue pagination if conditions are met
            if page_number < self.max_pages:
                next_page_number = page_number + 1
                next_url = f'https://httpbin.org/get?page={next_page_number}'
                
                yield Request(
                    url=next_url,
                    callback=self.parse,
                    meta={
                        'page_number': next_page_number,
                        'retry_count': 0,
                        'dont_cache': True
                    },
                    headers={
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                        'Accept': 'application/json, text/plain, */*',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Connection': 'keep-alive',
                        'Cache-Control': 'no-cache',
                    },
                    errback=self.errback_httpbin,
                    dont_filter=True
                )
            else:
                # Log completion
                total_time = time.time() - self.start_time
                self.logger.info(f"Hoàn thành crawling! Tổng thời gian: {total_time:.2f}s")
                self.logger.info(f"Trang thành công: {self.successful_pages}, Trang thất bại: {self.failed_pages}")
                
        except json.JSONDecodeError as e:
            self.logger.error(f"Lỗi JSON decode ở trang {page_number}: {e}")
            self.failed_pages += 1
            yield self.retry_request(response, f"JSON decode error: {e}")
            
        except Exception as e:
            self.logger.error(f"Lỗi không xác định ở trang {page_number}: {e}")
            self.failed_pages += 1
            yield self.retry_request(response, f"Unknown error: {e}")
    
    def retry_request(self, response, reason):
        """
        Retry request với exponential backoff
        """
        retry_count = response.meta.get('retry_count', 0)
        max_retries = 3
        
        if retry_count < max_retries:
            retry_count += 1
            delay = 2 ** retry_count  # Exponential backoff: 2, 4, 8 seconds
            
            self.logger.info(f"Retry {retry_count}/{max_retries} cho trang {response.meta.get('page_number')} sau {delay}s. Lý do: {reason}")
            
            return Request(
                url=response.url,
                callback=self.parse,
                meta={
                    'page_number': response.meta.get('page_number'),
                    'retry_count': retry_count,
                    'dont_cache': True
                },
                headers=response.request.headers,
                errback=self.errback_httpbin,
                dont_filter=True,
                priority=10  # Ưu tiên cao hơn
            )
        else:
            self.logger.error(f"Đã retry tối đa cho trang {response.meta.get('page_number')}. Bỏ qua.")
            return None
    
    def errback_httpbin(self, failure):
        """
        Handle errors và retry
        """
        request = failure.request
        page_number = request.meta.get('page_number', 'unknown')
        
        if failure.check(IgnoreRequest):
            self.logger.warning(f"IgnoreRequest cho trang {page_number}")
            return
        
        # Log error details
        if failure.check(scrapy.exceptions.TimeoutError):
            error_msg = f"Timeout error cho trang {page_number}"
        elif failure.check(scrapy.exceptions.DNSLookupError):
            error_msg = f"DNS lookup error cho trang {page_number}"
        elif failure.check(scrapy.exceptions.TCPTimedOutError):
            error_msg = f"TCP timeout error cho trang {page_number}"
        else:
            error_msg = f"HTTP error cho trang {page_number}: {failure.value}"
        
        self.logger.error(error_msg)
        self.failed_pages += 1
        
        # Retry logic
        retry_count = request.meta.get('retry_count', 0)
        max_retries = 3
        
        if retry_count < max_retries:
            retry_count += 1
            delay = 2 ** retry_count
            
            self.logger.info(f"Retry {retry_count}/{max_retries} cho trang {page_number} sau {delay}s")
            
            yield Request(
                url=request.url,
                callback=self.parse,
                meta={
                    'page_number': page_number,
                    'retry_count': retry_count,
                    'dont_cache': True
                },
                headers=request.headers,
                errback=self.errback_httpbin,
                dont_filter=True,
                priority=10
            )
        else:
            self.logger.error(f"Đã retry tối đa cho trang {page_number}. Bỏ qua.")
    
    def closed(self, reason):
        """
        Called when spider is closed
        """
        total_time = time.time() - self.start_time
        total_pages = self.successful_pages + self.failed_pages
        
        self.logger.info("=" * 50)
        self.logger.info("SPIDER HOÀN THÀNH")
        self.logger.info("=" * 50)
        self.logger.info(f"Tổng thời gian: {total_time:.2f} giây")
        self.logger.info(f"Tổng số trang: {total_pages}")
        self.logger.info(f"Trang thành công: {self.successful_pages}")
        self.logger.info(f"Trang thất bại: {self.failed_pages}")
        self.logger.info(f"Tỷ lệ thành công: {(self.successful_pages/total_pages*100):.2f}%" if total_pages > 0 else "0%")
        self.logger.info(f"Tốc độ: {total_pages/total_time:.2f} trang/giây" if total_time > 0 else "0 trang/giây")
        self.logger.info("=" * 50)
