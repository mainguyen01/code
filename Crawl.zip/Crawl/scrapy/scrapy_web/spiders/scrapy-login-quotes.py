import scrapy
from scrapy import FormRequest

class QuotesLoginSpider(scrapy.Spider):
    name = 'quotes_login'
    allowed_domains = ['quotes.toscrape.com']
    start_urls = ['https://quotes.toscrape.com/login']

    def parse(self, response):
        self.logger.info("Starting login process...")
        
        # Get CSRF token
        csrf_token = response.xpath("//input[@name='csrf_token']/@value").get()
        if not csrf_token:
            self.logger.error("CSRF token not found!")
            return
            
        self.logger.info(f"Found CSRF token: {csrf_token}")
        
        # Send login request
        yield FormRequest.from_response(
            response,
            formxpath='//form',
            formdata={
                'csrf_token': csrf_token,
                'username': 'admin',
                'password': 'admin'
            },
            callback=self.after_login
        )

    def after_login(self, response):
        # Check if login was successful
        logout_link = response.xpath("//a[@href='/logout']/text()").get()
        
        if logout_link:
            self.logger.info("✅ Successfully logged in!")
            self.logger.info("Starting to scrape quotes...")
            
            # Parse quotes from current page (after login redirect)
            yield from self.parse_quotes(response)
        else:
            self.logger.error("❌ Login failed! Check username/password.")
            # Check for error messages
            error_msg = response.xpath("//div[contains(@class, 'alert')]/text()").get()
            if error_msg:
                self.logger.error(f"Error message: {error_msg.strip()}")

    def parse_quotes(self, response):
        """Parse quotes after successful login"""
        quotes = response.xpath("//div[@class='quote']")
        
        for quote in quotes:
            text = quote.xpath(".//span[@class='text']/text()").get()
            author = quote.xpath(".//small[@class='author']/text()").get()
            tags = quote.xpath(".//div[@class='tags']//a/text()").getall()
            
            yield {
                'text': text,
                'author': author,
                'tags': tags
            }
            
        self.logger.info(f"Scraped {len(quotes)} quotes from current page")
        
        # Follow next page if available
        next_page = response.xpath("//li[@class='next']/a/@href").get()
        if next_page:
            next_url = response.urljoin(next_page)
            self.logger.info(f"Following next page: {next_url}")
            yield scrapy.Request(next_url, callback=self.parse_quotes)
        else:
            self.logger.info("✅ Finished scraping all pages!")
